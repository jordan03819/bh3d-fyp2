#include "AsteroidActor.h"
#include "Components/StaticMeshComponent.h"
#include "PhysicsEngine/PhysicsSettings.h"
#include "Engine/World.h"

AAsteroidActor::AAsteroidActor()
{
	PrimaryActorTick.TickInterval = 0.0f;
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.016f;

	AsteroidMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("AsteroidMesh"));
	RootComponent = AsteroidMesh;

	AsteroidMesh->SetSimulatePhysics(true);
	AsteroidMesh->SetEnableGravity(false);
	
	AsteroidMesh->BodyInstance.bLockXTranslation = false;
	AsteroidMesh->BodyInstance.bLockYTranslation = false;
	AsteroidMesh->BodyInstance.bLockZTranslation = false;
	AsteroidMesh->BodyInstance.bLockXRotation = false;
	AsteroidMesh->BodyInstance.bLockYRotation = false;
	AsteroidMesh->BodyInstance.bLockZRotation = false;

	AsteroidMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	AsteroidMesh->SetCollisionObjectType(ECC_WorldDynamic);
	AsteroidMesh->SetCollisionResponseToAllChannels(ECR_Ignore);
	AsteroidMesh->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Block);
	AsteroidMesh->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Block);

	AsteroidMesh->SetGenerateOverlapEvents(false);
	AsteroidMesh->SetMassScale(NAME_None, AsteroidMass);

	// REMOVED: Damping and MaxAngularVelocity access (must be in BeginPlay)
	// These trigger GEngine initialization during CDO construction

	AsteroidMesh->OnComponentHit.AddDynamic(this, &AAsteroidActor::OnAsteroidHit);
}

void AAsteroidActor::BeginPlay()
{
	Super::BeginPlay();
	InitializePhysics();
}

void AAsteroidActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bMaintainConstantSpeed)
	{
		MaintainConstantSpeed(DeltaTime);
	}
}

void AAsteroidActor::InitializePhysics()
{
	if (!AsteroidMesh)
	{
		return;
	}

	// NOW safe to set damping (GEngine is initialized)
	AsteroidMesh->BodyInstance.LinearDamping = 0.0f;
	AsteroidMesh->BodyInstance.AngularDamping = 0.0f;
	AsteroidMesh->BodyInstance.MaxAngularVelocity = 500.0f;

	// Random linear velocity
	FVector RandomDirection = FMath::VRand();
	float RandomSpeed = FMath::RandRange(MinLinearSpeed, MaxLinearSpeed);
	InitialLinearVelocity = RandomDirection * RandomSpeed;

	AsteroidMesh->SetPhysicsLinearVelocity(InitialLinearVelocity);

	FVector RandomSpinAxis = FMath::VRand();
	float RandomAngularSpeed = FMath::RandRange(MinAngularSpeed, MaxAngularSpeed);
	InitialAngularVelocity = RandomSpinAxis * RandomAngularSpeed;

	AsteroidMesh->SetPhysicsAngularVelocityInDegrees(InitialAngularVelocity);

	UE_LOG(LogTemp, Warning, TEXT("Asteroid initialized: Linear Vel = %s, Angular Vel = %s"),
		*InitialLinearVelocity.ToString(),
		*InitialAngularVelocity.ToString());
}

void AAsteroidActor::MaintainConstantSpeed(float DeltaTime)
{
	if (!AsteroidMesh)
	{
		return;
	}

	FVector CurrentVelocity = AsteroidMesh->GetPhysicsLinearVelocity();
	float CurrentSpeed = CurrentVelocity.Length();
	float TargetSpeed = InitialLinearVelocity.Length();

	// Only correct if speed drops below threshold
	if (CurrentSpeed < (TargetSpeed - SpeedTolerance))
	{
		float SpeedDeficit = TargetSpeed - CurrentSpeed;
		FVector CorrectionDirection = CurrentVelocity.GetSafeNormal();
		FVector Impulse = CorrectionDirection * SpeedDeficit * AsteroidMesh->GetMass();

		AsteroidMesh->AddImpulse(Impulse);
	}
}

void AAsteroidActor::OnAsteroidHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	// Collision happens automatically via physics engine
	// Restitution 0.95 handles bouncing
	// Torque from off-center impacts is applied automatically
	// Override this function if you need custom behavior (sounds, particle effects, damage, etc.)

	if (OtherActor && OtherActor != this)
	{
		// Log for debugging
		UE_LOG(LogTemp, Warning, TEXT("Asteroid hit: %s"), *OtherActor->GetName());

		// Example: Play a sound or particle effect here
		// PlayCollisionSound(Hit.ImpactPoint);
		// SpawnCollisionParticles(Hit.ImpactPoint);
	}
}
